// To do

// To do
Saison::Saison()
    // To do
{
}

// To do
Saison::Saison(unsigned int numSaison, unsigned int nbEpisodemax)
    // To do
{
}

// To do
Saison::Saison(const Saison& saison)
{
    // To do
}

// To do
Saison::~Saison()
{
    // To do
}

// To do
Saison& Saison::operator+=(std::unique_ptr<Episode> episode)
{
    // To do
}

// To do
Saison& Saison::operator-=(unsigned int numEpisode)
{
    // To do
}

// To do
bool Saison::operator==(unsigned int numSaison)
{
    // To do
}

// To do
std::ostream& operator<<(std::ostream& os, const Saison& saison)
{
    // To do
}

// To do
std::istream& operator>>(std::istream& is, Saison& saison)
{
    // To do
}

// To do
unsigned int Saison::getNumSaison() const
{
    // To do
}

// To do
size_t Saison::getNbEpisodes() const
{
   // To do
}

// To do
size_t Saison::trouverIndexEpisode(unsigned int numEpisode)
{
    // To do
}